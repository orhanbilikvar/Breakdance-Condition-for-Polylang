
 * Plugin Name:       Bde Condition for Polyland
 * Description:       Adds Polylang condition to template and elements. Source code https://pastebin.com/aALYKZkU. I changed the "supports" line.
 * Version:           1.0
 * Author:            Orhan Bilikvar
 * Author URI:        https://twitter.com/orhan_bilikvar
 * Text Domain: bde-condition-polylang
